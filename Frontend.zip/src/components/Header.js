import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { FiSearch } from "react-icons/fi";
import "./Header.css";

const Header = ({ user, onLogout }) => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [searchTimeout, setSearchTimeout] = useState(null);

  useEffect(() => {
    return () => {
      if (searchTimeout) {
        clearTimeout(searchTimeout);
      }
    };
  }, [searchTimeout]);

  const handleLogout = () => {
    onLogout();
    navigate("/login");
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    executeSearch();
  };

  const executeSearch = () => {
    if (searchTerm.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchTerm.trim())}`);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter") {
      if (searchTimeout) {
        clearTimeout(searchTimeout);
        setSearchTimeout(null);
      }
      executeSearch();
    }
  };

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);

    if (searchTimeout) {
      clearTimeout(searchTimeout);
    }

    const newTimeout = setTimeout(() => {
      if (e.target.value.trim()) {
        navigate(`/search?q=${encodeURIComponent(e.target.value.trim())}`);
      }
    }, 500);

    setSearchTimeout(newTimeout);
  };

  return (
    <header className="header">
      <Link to="/" className="logo">
        <h1>CodeUp</h1>
      </Link>

      <div className="search-wrapper">
        <form onSubmit={handleSearchSubmit}>
          <div className="search-input-container">
            <FiSearch 
              className="search-icon" 
              onClick={executeSearch}
              style={{ cursor: 'pointer' }}
            />
            <input
              type="text"
              name="search"
              value={searchTerm}
              onChange={handleSearchChange}
              onKeyDown={handleKeyDown}
              placeholder="Tìm kiếm khóa học..."
              aria-label="Tìm kiếm"
            />
          </div>
        </form>
      </div>

      <div className="buttons">
        {user ? (
          <>
            <span className="user-greeting">Xin chào, {user.email}</span>
            <Link to="/profile">
              <button className="profile-button">Hồ Sơ</button>
            </Link>
            <button className="logout" onClick={handleLogout}>
              Đăng xuất
            </button>
          </>
        ) : (
          <>
            <Link to="/login">
              <button className="login">Đăng nhập</button>
            </Link>
            <Link to="/register">
              <button className="register">Đăng ký</button>
            </Link>
          </>
        )}
      </div>
    </header>
  );
};

export default Header;