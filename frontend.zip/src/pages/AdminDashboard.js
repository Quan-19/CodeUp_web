import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const AdminDashboard = () => {
  const [view, setView] = useState('courses'); // 'courses' hoặc 'users'
  const [courses, setCourses] = useState([]);
  const [users, setUsers] = useState([]);
  const navigate = useNavigate();

  // Kiểm tra quyền admin
  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user'));
    if (!user || user.role !== 'admin') {
      navigate('/login');
    }
  }, [navigate]);

  // Lấy danh sách khóa học
  useEffect(() => {
    if (view === 'courses') {
      const fetchCourses = async () => {
        try {
          const token = localStorage.getItem('token');
          const res = await axios.get('http://localhost:5000/api/admin/courses', {
            headers: { Authorization: `Bearer ${token}` },
          });
          setCourses(res.data.data);
        } catch (err) {
          console.error('Lỗi khi tải khóa học:', err);
        }
      };
      fetchCourses();
    }
  }, [view]);

  // Lấy danh sách người dùng
  useEffect(() => {
    if (view === 'users') {
      const fetchUsers = async () => {
        try {
          const token = localStorage.getItem('token');
          const res = await axios.get('http://localhost:5000/api/admin/users', {
            headers: { Authorization: `Bearer ${token}` },
          });
          setUsers(res.data.data);
        } catch (err) {
          console.error('Lỗi khi tải người dùng:', err);
        }
      };
      fetchUsers();
    }
  }, [view]);

  // Xóa khóa học
  const handleDeleteCourse = async (id) => {
    if (!window.confirm('Bạn có chắc muốn xóa khóa học này?')) return;
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`http://localhost:5000/api/admin/courses/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setCourses(courses.filter((course) => course._id !== id));
    } catch (err) {
      console.error('Lỗi khi xóa khóa học:', err);
    }
  };

  // Xóa người dùng
  const handleDeleteUser = async (id) => {
    if (!window.confirm('Bạn có chắc muốn xóa người dùng này?')) return;
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`http://localhost:5000/api/admin/users/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setUsers(users.filter((user) => user._id !== id));
    } catch (err) {
      console.error('Lỗi khi xóa người dùng:', err);
    }
  };

  return (
    <div className="admin-dashboard">
      <h1>Trang quản trị Admin</h1>
      <div style={{ marginBottom: 20 }}>
        <button onClick={() => setView('courses')}>Quản lý khóa học</button>
        <button onClick={() => setView('users')}>Quản lý người dùng</button>
      </div>

      {view === 'courses' && (
        <>
          <h2>Danh sách khóa học</h2>
          <table border="1" cellPadding="8" style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr>
                <th>Tiêu đề</th>
                <th>Giá</th>
                <th>Ngày tạo</th>
                <th>Thao tác</th>
              </tr>
            </thead>
            <tbody>
              {courses.map((course) => (
                <tr key={course._id}>
                  <td>{course.title}</td>
                  <td>{course.price} VND</td>
                  <td>{new Date(course.createdAt).toLocaleString()}</td>
                  <td>
                    <button onClick={() => handleDeleteCourse(course._id)}>Xóa</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </>
      )}

      {view === 'users' && (
        <>
          <h2>Danh sách người dùng</h2>
          <table border="1" cellPadding="8" style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr>
                <th>Email</th>
                <th>Username</th>
                <th>Vai trò</th>
                <th>Ngày tạo</th>
                <th>Thao tác</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr key={user._id}>
                  <td>{user.email}</td>
                  <td>{user.username}</td>
                  <td>{user.role}</td>
                  <td>{new Date(user.createdAt).toLocaleString()}</td>
                  <td>
                    <button onClick={() => handleDeleteUser(user._id)}>Xóa</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </>
      )}
    </div>
  );
};

export default AdminDashboard;
