import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Register.css";

const Register = () => {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("student");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleRegister = async (e) => {
    e.preventDefault();
    setError("");

    try {
      const res = await fetch("http://localhost:5000/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, email, password, role }),
      });

      const data = await res.json();
      if (res.ok) {
        localStorage.setItem("token", data.token);
        localStorage.setItem("user", JSON.stringify(data.user));

        // 👉 Điều hướng theo vai trò
        if (data.user.role === "admin") {
          navigate("/admin/dashboard");
        } else if (data.user.role === "instructor") {
          navigate("/instructor/dashboard");
        } else {
          navigate("/student/dashboard");
        }
      } else {
        setError(data.error || "Đăng ký thất bại.");
      }
    } catch (err) {
      setError("Không thể kết nối tới máy chủ.");
    }
  };

  return (
    <div className="register-container">
      <h2>Đăng ký</h2>

      {error && <div className="error-message">{error}</div>}

      <form onSubmit={handleRegister}>
        <input
          type="text"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          placeholder="Tên người dùng"
          required
        />

        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Email"
          required
        />

        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Mật khẩu"
          required
        />

        <select value={role} onChange={(e) => setRole(e.target.value)}>
          <option value="student">Học viên</option>
          <option value="instructor">Người dạy</option>
        </select>

        <button type="submit">Đăng ký</button>
      </form>
      <div className="login-link">
        Đã có tài khoản? <a href="/Login">Đăng nhập</a>
      </div>
    </div>
  );
};

export default Register;
